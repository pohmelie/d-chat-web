import struct


get_raw = lambda fname: open(fname, mode="rb", buffering=0).readall()
data = bytes.join(b"", map(get_raw, ("Game.exe", "Bnclient.dll", "D2Client.dll")))
nums = struct.unpack(str.format("{}I", len(data) // 4), data)

print("this.binaries = [" + ", ".join(map(str, nums)) + "]", file=open("binaries.js", "w"), flush=True)
