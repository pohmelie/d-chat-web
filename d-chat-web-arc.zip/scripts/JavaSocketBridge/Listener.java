// Listener.java
// by Stephen Ware
// April 25, 2009
//
// Part of the JavaSocketBridge project.
// This class listens for input from a given socket.

import java.io.*;
import java.net.*;

// Thread that listens for input
public class Listener extends Thread{

	// Instance variables
	JavaSocketBridge parent;	// Report to this object
	Socket socket;				// Listen to this socket
	InputStream in;			    // Input
	boolean running = false;	// Am I still running?
    byte[] buffer = new byte[65536];

	// Constructor
	public Listener(Socket s, JavaSocketBridge b) throws IOException{
		parent = b;
		socket = s;
		in = s.getInputStream();
	}

	// Close
	public void close() throws IOException{
		if(running == false) return;
		running = false;
		socket.close();
		in.close();
	}

	// Main loop
	public void run(){
		running = true;
		int count;
		while(running){
			try{
				count = in.read(buffer);
				if(count == 0){
					parent.disconnect();
					close();
				}
				else{
					parent.hear(buffer.clone(), count);
				}
			}
			catch(Exception ex){
				if(running){
					parent.error("An error occured while reading from the socket\n"+ex.getMessage());
					parent.disconnect();
					try{ close(); } catch(Exception ex2){}
				}
			}
		}
		try{ close(); } catch(Exception ex){}
	}
}
